# frozen_string_literal: true

require 'thor'
require 'json'
require_relative 'cli/commands/search_command'
require_relative 'cli/commands/list_collectors_command'
require_relative 'cli/commands/list_sources_command'
require_relative 'cli/commands/discover_source_metadata_command'
require_relative 'cli/commands/list_monitors_command'
require_relative 'cli/commands/get_monitor_command'
require_relative 'cli/commands/list_folders_command'
require_relative 'cli/commands/list_dashboards_command'
require_relative 'cli/commands/get_dashboard_command'
require_relative 'cli/commands/list_health_events_command'
require_relative 'cli/commands/list_fields_command'
require_relative 'cli/commands/get_lookup_command'
require_relative 'cli/commands/list_apps_command'
require_relative 'cli/commands/get_content_command'
require_relative 'cli/commands/export_content_command'

module Sumologic
  # Thor-based CLI for Sumo Logic query tool
  # Delegates commands to specialized command classes
  class CLI < Thor # rubocop:disable Metrics/ClassLength
    class_option :debug, type: :boolean, aliases: '-d', desc: 'Enable debug output'
    class_option :output, type: :string, aliases: '-o', desc: 'Output file (default: stdout)'

    def self.exit_on_failure?
      true
    end

    def initialize(*args)
      super
      $DEBUG = true if options[:debug]
    end

    desc 'search', 'Search Sumo Logic logs'
    long_desc <<~DESC
      Search Sumo Logic logs using a query string.

      Time Formats:
        --from and --to support multiple formats:
        • 'now' - current time
        • Relative: '-30s', '-5m', '-2h', '-1h30m', '-7d', '-1w', '-1M' (compound supported)
        • Unix timestamp: '1700000000' (seconds since epoch)
        • ISO 8601: '2025-11-13T14:00:00'

      Aggregation Mode (--aggregate):
        Use --aggregate (-a) for queries with count, sum, avg, group by, etc.
        Returns aggregation records instead of raw log messages.

      Examples:
        # Last 30 minutes
        sumo-query search --query 'error' --from '-30m' --to 'now'

        # Last hour with ISO format
        sumo-query search --query 'error | timeslice 5m | count' \\
          --from '2025-11-13T14:00:00' --to '2025-11-13T15:00:00'

        # Last 7 days
        sumo-query search --query '"connection timeout"' \\
          --from '-7d' --to 'now' --limit 100

        # Using Unix timestamps
        sumo-query search --query 'error' \\
          --from '1700000000' --to '1700003600'

        # Interactive mode with FZF
        sumo-query search --query 'error' \\
          --from '-1h' --to 'now' --interactive

        # Aggregation query (count by source)
        sumo-query search --query '* | count by _sourceCategory' \\
          --from '-1h' --to 'now' --aggregate

        # Top errors by count
        sumo-query search --query 'error | count by _sourceHost | top 10' \\
          --from '-24h' --to 'now' --aggregate
    DESC
    option :query, type: :string, required: true, aliases: '-q', desc: 'Search query'
    option :from, type: :string, required: true, aliases: '-f', desc: 'Start time (now, -30m, unix timestamp, ISO 8601)'
    option :to, type: :string, required: true, aliases: '-t', desc: 'End time (now, -30m, unix timestamp, ISO 8601)'
    option :time_zone, type: :string, default: 'UTC', aliases: '-z',
                       desc: 'Time zone (UTC, EST, AEST, +00:00, America/New_York, Australia/Sydney)'
    option :limit, type: :numeric, aliases: '-l', desc: 'Maximum messages to return'
    option :aggregate, type: :boolean, aliases: '-a', desc: 'Return aggregation records (for count/group by queries)'
    option :interactive, type: :boolean, aliases: '-i', desc: 'Launch interactive browser (requires fzf)'
    def search
      Commands::SearchCommand.new(options, create_client).execute
    end

    desc 'list-collectors', 'List Sumo Logic collectors with optional filters'
    long_desc <<~DESC
      List collectors in your Sumo Logic account.
      Supports filtering by name/category and limiting results.

      Examples:
        sumo-query list-collectors -q "my-service" -l 20
        sumo-query list-collectors --output collectors.json
    DESC
    option :query, type: :string, aliases: '-q', desc: 'Filter by name or category (case-insensitive)'
    option :limit, type: :numeric, aliases: '-l', desc: 'Maximum collectors to return'
    def list_collectors
      Commands::ListCollectorsCommand.new(options, create_client).execute
    end

    desc 'list-sources', 'List sources from collectors with optional filters'
    long_desc <<~DESC
      List sources from all collectors, or from a specific collector.
      Supports filtering by collector name, source name, and category.

      Examples:
        sumo-query list-sources --collector "my-service" --name "nginx" -l 20
        sumo-query list-sources --category "production"
        sumo-query list-sources --collector-id 12345
    DESC
    option :collector_id, type: :string, desc: 'Collector ID to list sources for'
    option :collector, type: :string, desc: 'Filter by collector name (case-insensitive)'
    option :name, type: :string, aliases: '-n', desc: 'Filter by source name (case-insensitive)'
    option :category, type: :string, desc: 'Filter by source category (case-insensitive)'
    option :limit, type: :numeric, aliases: '-l', desc: 'Maximum total sources to return'
    def list_sources
      Commands::ListSourcesCommand.new(options, create_client).execute
    end

    desc 'discover-source-metadata', 'Discover source metadata from log data using search aggregation'
    long_desc <<~DESC
      Discovers source metadata from actual log data using search aggregation.
      Useful for CloudWatch/ECS/Lambda sources with dynamic _sourceName values
      that are not visible in the Collectors API.

      Note: This is not an official Sumo Logic API. It runs the search query:
        * | count by _sourceName, _sourceCategory | sort by _count desc
      This is a well-known technique in the Sumo Logic community to discover
      runtime sources, complementing the static source configuration from
      the Collectors API (list-sources).

      Time Formats:
        --from and --to support multiple formats:
        • 'now' - current time
        • Relative: '-30s', '-5m', '-2h', '-1h30m', '-7d', '-1w', '-1M' (compound supported)
        • Unix timestamp: '1700000000' (seconds since epoch)
        • ISO 8601: '2025-11-13T14:00:00'

      Examples:
        # Discover all sources from last 24 hours (default)
        sumo-query discover-source-metadata

        # Discover sources from last 7 days
        sumo-query discover-source-metadata --from '-7d' --to 'now'

        # Filter by source category (ECS only)
        sumo-query discover-source-metadata --filter '_sourceCategory=*ecs*'

        # Filter results by keyword (matches name or category)
        sumo-query discover-source-metadata --keyword nginx
        sumo-query discover-source-metadata --keyword nginx -l 10

        # Save to file
        sumo-query discover-source-metadata --output discovered-sources.json
    DESC
    option :from, type: :string, default: '-24h', aliases: '-f',
                  desc: 'Start time (default: -24h)'
    option :to, type: :string, default: 'now', aliases: '-t',
                desc: 'End time (default: now)'
    option :time_zone, type: :string, default: 'UTC', aliases: '-z',
                       desc: 'Time zone (UTC, EST, AEST, +00:00, America/New_York, Australia/Sydney)'
    option :filter, type: :string, desc: 'Optional filter query (e.g., _sourceCategory=*ecs*)'
    option :keyword, type: :string, aliases: '-k', desc: 'Filter results by keyword (matches name or category)'
    option :limit, type: :numeric, aliases: '-l', desc: 'Maximum number of sources to return'
    def discover_source_metadata
      Commands::DiscoverSourceMetadataCommand.new(options, create_client).execute
    end

    # ============================================================
    # Monitors Commands
    # ============================================================

    desc 'list-monitors', 'List monitors with optional status and query filters'
    long_desc <<~DESC
      List monitors in your Sumo Logic account using the search API.
      Supports filtering by monitor status and text query.

      Status Values:
        Normal, Critical, Warning, MissingData, Disabled, AllTriggered

      Examples:
        # List all monitors
        sumo-query list-monitors

        # List only critical monitors
        sumo-query list-monitors --status Critical

        # List all currently triggered monitors
        sumo-query list-monitors --status AllTriggered

        # Search monitors by name
        sumo-query list-monitors --query "prod"

        # Combine status and query filters
        sumo-query list-monitors --status Warning --query "latency"

        # Save to file
        sumo-query list-monitors --output monitors.json
    DESC
    option :limit, type: :numeric, aliases: '-l', default: 100, desc: 'Maximum monitors to return'
    option :status, type: :string, aliases: '-s',
                    desc: 'Filter by status (Normal, Critical, Warning, MissingData, Disabled, AllTriggered)'
    option :query, type: :string, aliases: '-q', desc: 'Search query to filter monitors'
    def list_monitors
      Commands::ListMonitorsCommand.new(options, create_client).execute
    end

    desc 'get-monitor', 'Get a specific monitor by ID'
    long_desc <<~DESC
      Get detailed information about a specific monitor.

      Example:
        sumo-query get-monitor --monitor-id 0000000000123456
    DESC
    option :monitor_id, type: :string, required: true, desc: 'Monitor ID'
    # rubocop:disable Naming/AccessorMethodName -- Thor CLI command, not a getter
    def get_monitor
      Commands::GetMonitorCommand.new(options, create_client).execute
    end
    # rubocop:enable Naming/AccessorMethodName

    # ============================================================
    # Folders Commands (Content Library)
    # ============================================================

    desc 'list-folders', 'List folders in content library'
    long_desc <<~DESC
      List folders in the Sumo Logic content library.
      By default, shows your personal folder.

      Examples:
        # List personal folder contents
        sumo-query list-folders

        # List specific folder
        sumo-query list-folders --folder-id 0000000000123456

        # Get folder tree (recursive)
        sumo-query list-folders --tree --depth 3

        # Save to file
        sumo-query list-folders --output folders.json
    DESC
    option :folder_id, type: :string, desc: 'Folder ID to list (default: personal folder)'
    option :tree, type: :boolean, desc: 'Fetch recursive tree structure'
    option :depth, type: :numeric, default: 3, desc: 'Maximum tree depth (default: 3)'
    def list_folders
      Commands::ListFoldersCommand.new(options, create_client).execute
    end

    # ============================================================
    # Dashboards Commands
    # ============================================================

    desc 'list-dashboards', 'List all dashboards'
    long_desc <<~DESC
      List all dashboards in your Sumo Logic account.

      Examples:
        # List all dashboards
        sumo-query list-dashboards

        # List dashboards with limit
        sumo-query list-dashboards --limit 50

        # Save to file
        sumo-query list-dashboards --output dashboards.json
    DESC
    option :limit, type: :numeric, aliases: '-l', default: 100, desc: 'Maximum dashboards to return'
    def list_dashboards
      Commands::ListDashboardsCommand.new(options, create_client).execute
    end

    desc 'get-dashboard', 'Get a specific dashboard by ID'
    long_desc <<~DESC
      Get detailed information about a specific dashboard including panels.

      Example:
        sumo-query get-dashboard --dashboard-id 0000000000123456
    DESC
    option :dashboard_id, type: :string, required: true, desc: 'Dashboard ID'
    # rubocop:disable Naming/AccessorMethodName -- Thor CLI command, not a getter
    def get_dashboard
      Commands::GetDashboardCommand.new(options, create_client).execute
    end
    # rubocop:enable Naming/AccessorMethodName

    # ============================================================
    # Health Events Commands
    # ============================================================

    desc 'list-health-events', 'List health events for collectors, sources, and ingest budgets'
    long_desc <<~DESC
      List health events from your Sumo Logic account.
      Shows collector, source, and ingest budget health status.

      Examples:
        # List health events
        sumo-query list-health-events

        # Save to file
        sumo-query list-health-events --output health.json
    DESC
    option :limit, type: :numeric, aliases: '-l', default: 100, desc: 'Maximum events to return'
    def list_health_events
      Commands::ListHealthEventsCommand.new(options, create_client).execute
    end

    # ============================================================
    # Fields Commands
    # ============================================================

    desc 'list-fields', 'List custom or built-in log fields'
    long_desc <<~DESC
      List fields available in your Sumo Logic account.
      By default, lists custom fields. Use --builtin for built-in fields.

      Examples:
        # List custom fields
        sumo-query list-fields

        # List built-in fields
        sumo-query list-fields --builtin

        # Save to file
        sumo-query list-fields --output fields.json
    DESC
    option :builtin, type: :boolean, desc: 'List built-in fields instead of custom fields'
    def list_fields
      Commands::ListFieldsCommand.new(options, create_client).execute
    end

    # ============================================================
    # Lookup Tables Commands
    # ============================================================

    desc 'get-lookup', 'Get a specific lookup table by ID'
    long_desc <<~DESC
      Get detailed information about a specific lookup table.
      Note: There is no list-all endpoint for lookup tables in the Sumo Logic API.

      Example:
        sumo-query get-lookup --lookup-id 0000000000123456
    DESC
    option :lookup_id, type: :string, required: true, desc: 'Lookup table ID'
    # rubocop:disable Naming/AccessorMethodName -- Thor CLI command, not a getter
    def get_lookup
      Commands::GetLookupCommand.new(options, create_client).execute
    end
    # rubocop:enable Naming/AccessorMethodName

    # ============================================================
    # Apps Commands (Catalog)
    # ============================================================

    desc 'list-apps', 'List available apps from the Sumo Logic catalog'
    long_desc <<~DESC
      List apps available in the Sumo Logic app catalog.
      Note: This lists the catalog of available apps, not installed apps.

      Examples:
        # List all available apps
        sumo-query list-apps

        # Save to file
        sumo-query list-apps --output apps.json
    DESC
    def list_apps
      Commands::ListAppsCommand.new(options, create_client).execute
    end

    # ============================================================
    # Content Library Commands (path-based)
    # ============================================================

    desc 'get-content', 'Get a content item by its library path'
    long_desc <<~DESC
      Look up a content item in the Sumo Logic content library by its path.
      Returns the item ID, type, name, and parent folder.

      Examples:
        # Get content by path
        sumo-query get-content --path '/Library/Users/me/My Saved Search'

        # Save to file
        sumo-query get-content --path '/Library/Users/me/Dashboard' --output content.json
    DESC
    option :path, type: :string, required: true, aliases: '-p', desc: 'Content library path'
    # rubocop:disable Naming/AccessorMethodName -- Thor CLI command, not a getter
    def get_content
      Commands::GetContentCommand.new(options, create_client).execute
    end
    # rubocop:enable Naming/AccessorMethodName

    desc 'export-content', 'Export a content item as JSON'
    long_desc <<~DESC
      Export a content library item (search, dashboard, folder) as JSON.
      Handles the async export job automatically (start, poll, fetch result).

      Examples:
        # Export by content ID
        sumo-query export-content --content-id 0000000000123456

        # Save export to file
        sumo-query export-content --content-id 0000000000123456 --output export.json
    DESC
    option :content_id, type: :string, required: true, desc: 'Content item ID to export'
    def export_content
      Commands::ExportContentCommand.new(options, create_client).execute
    end

    # ============================================================
    # Utility Commands
    # ============================================================

    desc 'version', 'Show version information'
    def version
      puts "sumo-query version #{Sumologic::VERSION}"
    end
    map %w[-v --version] => :version

    default_task :search

    private

    def create_client
      Client.new
    rescue AuthenticationError => e
      error "Authentication Error: #{e.message}"
      error "\nPlease set environment variables:"
      error "  export SUMO_ACCESS_ID='your_access_id'"
      error "  export SUMO_ACCESS_KEY='your_access_key'"
      error "  export SUMO_DEPLOYMENT='us2'  # Optional, defaults to us2"
      exit 1
    rescue Error => e
      error "Error: #{e.message}"
      exit 1
    end

    def error(message)
      warn message
    end
  end
end
