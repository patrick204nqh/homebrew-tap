# frozen_string_literal: true

module Sumologic
  # Centralized configuration for Sumo Logic client
  class Configuration
    attr_accessor :access_id, :access_key, :deployment, :timeout, :initial_poll_interval, :max_poll_interval,
                  :poll_backoff_factor, :max_messages_per_request, :max_workers, :request_delay,
                  :connect_timeout, :read_timeout, :max_retries, :retry_base_delay, :retry_max_delay

    API_VERSION = 'v1'

    def initialize
      # Authentication
      @access_id = ENV.fetch('SUMO_ACCESS_ID', nil)
      @access_key = ENV.fetch('SUMO_ACCESS_KEY', nil)
      @deployment = ENV['SUMO_DEPLOYMENT'] || 'us2'

      # Search job polling
      @initial_poll_interval = 2 # seconds - aggressive polling for faster response
      @max_poll_interval = 15 # seconds - slow down for large queries
      @poll_backoff_factor = 1.5 # increase interval by 50% each time

      # Timeouts and limits
      @timeout = 300 # seconds (5 minutes) - overall operation timeout
      @connect_timeout = ENV.fetch('SUMO_CONNECT_TIMEOUT', '10').to_i # seconds
      @read_timeout = ENV.fetch('SUMO_READ_TIMEOUT', '60').to_i # seconds
      @max_messages_per_request = 10_000

      # Retry configuration
      @max_retries = ENV.fetch('SUMO_MAX_RETRIES', '3').to_i
      @retry_base_delay = ENV.fetch('SUMO_RETRY_BASE_DELAY', '1.0').to_f # seconds
      @retry_max_delay = ENV.fetch('SUMO_RETRY_MAX_DELAY', '30.0').to_f # seconds

      # Rate limiting (default: 5 workers, 250ms delay)
      @max_workers = ENV.fetch('SUMO_MAX_WORKERS', '5').to_i
      @request_delay = ENV.fetch('SUMO_REQUEST_DELAY', '0.25').to_f
    end

    def base_url
      @base_url ||= build_base_url
    end

    # Base URL for v2 API endpoints (Content Library, etc.)
    def base_url_v2
      @base_url_v2 ||= build_base_url('v2')
    end

    def web_ui_base_url
      @web_ui_base_url ||= build_web_ui_base_url
    end

    def validate!
      raise AuthenticationError, 'SUMO_ACCESS_ID not set' unless @access_id
      raise AuthenticationError, 'SUMO_ACCESS_KEY not set' unless @access_key
    end

    private

    def build_web_ui_base_url
      case @deployment
      when /^http/
        @deployment.sub('api.', 'service.').sub(%r{/api/v\d+.*}, '')
      when 'us1'
        'https://service.sumologic.com'
      when 'us2'
        'https://service.us2.sumologic.com'
      when 'eu'
        'https://service.eu.sumologic.com'
      when 'au'
        'https://service.au.sumologic.com'
      else
        "https://service.#{@deployment}.sumologic.com"
      end
    end

    def build_base_url(version = API_VERSION)
      case @deployment
      when /^http/
        # Full URL provided - replace version if present
        @deployment.sub(%r{/api/v\d+}, "/api/#{version}")
      when 'us1'
        "https://api.sumologic.com/api/#{version}"
      when 'us2'
        "https://api.us2.sumologic.com/api/#{version}"
      when 'eu'
        "https://api.eu.sumologic.com/api/#{version}"
      when 'au'
        "https://api.au.sumologic.com/api/#{version}"
      else
        "https://api.#{@deployment}.sumologic.com/api/#{version}"
      end
    end
  end
end
