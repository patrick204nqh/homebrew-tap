# frozen_string_literal: true

module Sumologic
  VERSION = '1.3.2'
end
