# frozen_string_literal: true

require_relative 'message_fetcher'
require_relative 'record_fetcher'

module Sumologic
  module Search
    # Manages search job lifecycle: create, poll, fetch, delete
    class Job
      def initialize(http_client:, config:)
        @http = http_client
        @config = config
        @poller = Poller.new(http_client: http_client, config: config)
        @message_fetcher = MessageFetcher.new(http_client: http_client, config: config)
        @record_fetcher = RecordFetcher.new(http_client: http_client, config: config)
      end

      # Execute a complete search workflow for raw messages
      # Returns array of messages
      def execute(query:, from_time:, to_time:, time_zone: 'UTC', limit: nil)
        job_id = create(query, from_time, to_time, time_zone)
        @poller.poll(job_id)
        messages = @message_fetcher.fetch_all(job_id, limit: limit)
        delete(job_id)
        messages
      rescue StandardError => e
        delete(job_id) if job_id
        raise Error, "Search failed: #{e.message}"
      end

      # Execute a complete search workflow for aggregation records
      # Use this for queries with: count by, group by, etc.
      # Returns array of records
      def execute_aggregation(query:, from_time:, to_time:, time_zone: 'UTC', limit: nil)
        job_id = create(query, from_time, to_time, time_zone)
        @poller.poll(job_id)
        records = @record_fetcher.fetch_all(job_id, limit: limit)
        delete(job_id)
        records
      rescue StandardError => e
        delete(job_id) if job_id
        raise Error, "Search failed: #{e.message}"
      end

      private

      def create(query, from_time, to_time, time_zone)
        data = @http.request(
          method: :post,
          path: '/search/jobs',
          body: {
            query: query,
            from: from_time,
            to: to_time,
            timeZone: time_zone
          }
        )

        raise Error, "Failed to create job: #{data['message']}" unless data['id']

        log_info "Created search job: #{data['id']}"
        data['id']
      end

      def delete(job_id)
        return unless job_id

        @http.request(
          method: :delete,
          path: "/search/jobs/#{job_id}"
        )
        log_info "Deleted search job: #{job_id}"
      rescue StandardError => e
        log_error "Failed to delete job #{job_id}: #{e.message}"
      end

      def log_info(message)
        # Always show job creation (with ID) for user reference
        if message.start_with?('Created search job:')
          warn "  #{message}"
        elsif ENV['SUMO_DEBUG'] || $DEBUG
          warn "[Sumologic::Search::Job] #{message}"
        end
      end

      def log_error(message)
        warn "[Sumologic::Search::Job ERROR] #{message}"
      end
    end
  end
end
