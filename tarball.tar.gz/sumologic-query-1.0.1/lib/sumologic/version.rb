# frozen_string_literal: true

module Sumologic
  VERSION = '1.0.1'
end
