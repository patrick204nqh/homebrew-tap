# frozen_string_literal: true

module Sumologic
  VERSION = '1.1.1'
end
